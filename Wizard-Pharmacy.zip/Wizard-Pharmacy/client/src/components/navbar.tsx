import { Link } from "wouter";
import { Sparkles } from "lucide-react";

export function Navbar() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-primary/10">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        
        <Link href="/" className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-wider text-foreground">
            Wizzard Pharmacy
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => scrollTo("about")} className="text-sm font-medium text-foreground/70 hover:text-primary transition-colors">
            About
          </button>
          <button onClick={() => scrollTo("order")} className="text-sm font-medium text-foreground/70 hover:text-primary transition-colors">
            Potions
          </button>
          <button onClick={() => scrollTo("contact")} className="text-sm font-medium text-foreground/70 hover:text-primary transition-colors">
            Contact
          </button>
          <button onClick={() => scrollTo("order")} className="px-5 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary font-semibold hover:bg-primary hover:text-primary-foreground transition-all duration-300">
            Order Now
          </button>
        </div>

      </div>
    </nav>
  );
}
