import { Sparkles } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-background border-t border-primary/20 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <span className="font-display font-bold text-lg tracking-wider">
            Wizzard Pharmacy
          </span>
        </div>
        
        <p className="text-muted-foreground text-sm text-center md:text-right">
          © {new Date().getFullYear()} Wizzard Pharmacy. All magical rights reserved.
          <br /> Crafted with care and a sprinkle of glitter.
        </p>
      </div>
    </footer>
  );
}
