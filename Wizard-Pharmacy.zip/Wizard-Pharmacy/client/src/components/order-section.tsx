import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useProducts } from "@/hooks/use-products";
import { useCreateOrder } from "@/hooks/use-orders";
import { Loader2, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const orderSchema = z.object({
  customerName: z.string().min(2, "Name must be at least 2 characters"),
  productId: z.coerce.number({ invalid_type_error: "Please select a product" }).min(1, "Please select a product"),
  feedback: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderSchema>;

export function OrderSection() {
  const { data: products, isLoading: isLoadingProducts } = useProducts();
  const createOrder = useCreateOrder();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      customerName: "",
      productId: 0,
      feedback: "",
    },
  });

  const onSubmit = async (data: OrderFormData) => {
    try {
      setIsSubmitting(true);
      
      // 1. Submit to the API
      await createOrder.mutateAsync(data);
      
      // 2. EMAILJS PLACEHOLDER
      // INFO: To enable email notifications, follow these steps:
      // 1. Install the SDK: npm install @emailjs/browser
      // 2. Import it at the top: import emailjs from '@emailjs/browser';
      // 3. Replace the placeholder below with your actual IDs from the EmailJS dashboard.
      
      // const templateParams = {
      //   from_name: data.customerName,
      //   product_id: data.productId,
      //   feedback: data.feedback || "None provided"
      // };
      
      // await emailjs.send(
      //   'YOUR_SERVICE_ID', 
      //   'YOUR_TEMPLATE_ID', 
      //   templateParams, 
      //   'YOUR_PUBLIC_KEY'
      // );
      
      toast({
        title: "✨ Order Conjured Successfully!",
        description: "Your potion will be prepared soon.",
      });
      
      form.reset();
    } catch (err: any) {
      toast({
        title: "Failed to place order",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="order" className="py-24 px-6 relative">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-gradient-gold">Acquire Your Potion</h2>
          <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
            Our potions are lovingly handcrafted for just ~$8. Select your desired essence below, and tell us a bit about yourself.
          </p>

          <div className="glass-card p-8 rounded-3xl relative overflow-hidden">
            {/* Decorative background flare */}
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-primary/20 blur-3xl rounded-full" />
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 relative z-10">
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">Your Name</label>
                <input
                  {...form.register("customerName")}
                  className="w-full bg-background/50 border border-primary/20 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground placeholder:text-muted-foreground/50"
                  placeholder="Enter your magical moniker"
                />
                {form.formState.errors.customerName && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.customerName.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">Select Potion</label>
                <select
                  {...form.register("productId")}
                  className="w-full bg-background/50 border border-primary/20 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground appearance-none"
                  disabled={isLoadingProducts}
                >
                  <option value="0" disabled>Select a potion...</option>
                  {products?.map((p) => (
                    <option key={p.id} value={p.id} className="bg-background text-foreground">
                      {p.name} - {p.price}
                    </option>
                  ))}
                  {/* Fallback if no products seeded yet */}
                  {!products?.length && !isLoadingProducts && (
                    <option value="1">Starlight Serenity - $8.00</option>
                  )}
                </select>
                {form.formState.errors.productId && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.productId.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">What caught your eye? (Optional)</label>
                <textarea
                  {...form.register("feedback")}
                  className="w-full bg-background/50 border border-primary/20 rounded-xl px-4 py-3 min-h-[100px] focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground placeholder:text-muted-foreground/50"
                  placeholder="What do you love about our potions?"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-gradient-to-r from-primary/80 to-primary text-primary-foreground font-bold rounded-xl hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Casting spell...</>
                ) : (
                  <><Send className="w-5 h-5" /> Submit Order</>
                )}
              </button>

            </form>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="hidden lg:block relative"
        >
          {/* Aesthetic mystical bottle image placeholder */}
          <div className="relative rounded-[2rem] overflow-hidden shadow-2xl border-4 border-primary/10">
            {/* aesthetic glowing glass bottle */}
            <img 
              src="https://images.unsplash.com/photo-1618666012174-83b441c0bc76?auto=format&fit=crop&q=80" 
              alt="Magical Potion Bottle" 
              className="w-full h-[600px] object-cover hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
          </div>
        </motion.div>

      </div>
    </section>
  );
}
