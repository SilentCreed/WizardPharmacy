import { motion } from "framer-motion";

export function TeamSection() {
  const producers = [
    { name: "James Lambert", role: "Master Alchemist", image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop" },
    { name: "Ina Allen", role: "Charm Weaver", image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop" },
    { name: "Kayden Hakes", role: "Oil Specialist", image: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&h=400&fit=crop" },
    { name: "Liam Biltz", role: "Glitter Mage", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop" },
    { name: "Layne Glackin", role: "Sensory Curator", image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=400&fit=crop" },
  ];

  return (
    <section className="py-24 px-6 bg-secondary/30 border-y border-primary/10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-gradient-gold">Meet the Guild</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            The talented producers behind every mesmerizing bottle.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-8">
          {producers.map((producer, idx) => (
            <motion.div
              key={producer.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="flex flex-col items-center w-40 sm:w-48 text-center group"
            >
              <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden mb-4 border-2 border-primary/20 group-hover:border-primary transition-colors duration-300 p-1">
                {/* placeholder portrait image */}
                <img 
                  src={producer.image} 
                  alt={producer.name}
                  className="w-full h-full object-cover rounded-full filter sepia-[0.3] hover:sepia-0 transition-all duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-foreground">{producer.name}</h3>
              <p className="text-sm text-primary mt-1">{producer.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
