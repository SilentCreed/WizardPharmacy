import { motion } from "framer-motion";
import { Droplet, Stars, Heart } from "lucide-react";

export function AboutSection() {
  const features = [
    {
      icon: <Droplet className="w-8 h-8 text-primary" />,
      title: "Soothing Oils",
      description: "Carefully selected carrying oils that create a mesmerizing, slow-motion flow inside every bottle."
    },
    {
      icon: <Stars className="w-8 h-8 text-primary" />,
      title: "Magical Glitters",
      description: "Holographic and iridescent glitters that catch the light, creating a galaxy of swirling stars."
    },
    {
      icon: <Heart className="w-8 h-8 text-primary" />,
      title: "Mystic Charms",
      description: "Hidden within the depths are tiny, mystical charms waiting to be discovered as the potion settles."
    }
  ];

  return (
    <section id="about" className="py-24 px-6 relative z-10 bg-background/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold mb-4 text-gradient-gold"
          >
            The Alchemy Within
          </motion.h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Every sensory bottle is a masterwork of patience and magic, designed to bring calm and wonder to your day.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="glass-card rounded-3xl p-8 text-center magical-glow group"
            >
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4 text-foreground">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
