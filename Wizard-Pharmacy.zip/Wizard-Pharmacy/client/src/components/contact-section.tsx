import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateContact } from "@/hooks/use-contacts";
import { Mail, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormData = z.infer<typeof contactSchema>;

export function ContactSection() {
  const createContact = useCreateContact();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const onSubmit = async (data: ContactFormData) => {
    try {
      setIsSubmitting(true);
      await createContact.mutateAsync(data);
      
      // EMAILJS PLACEHOLDER
      // INFO: To enable email notifications for contact messages:
      // 1. Install the SDK: npm install @emailjs/browser
      // 2. Import it at the top: import emailjs from '@emailjs/browser';
      // 3. Use the code below with your EmailJS IDs:
      
      // const templateParams = {
      //   from_name: data.name,
      //   from_email: data.email,
      //   message: data.message
      // };
      // await emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', templateParams, 'YOUR_PUBLIC_KEY');

      toast({
        title: "Message Sent!",
        description: "Our owls will deliver your message shortly.",
      });
      
      form.reset();
    } catch (err: any) {
      toast({
        title: "Delivery Failed",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 px-6 border-t border-primary/10">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Mail className="w-12 h-12 text-primary mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gradient-gold">Send a Missive</h2>
          <p className="text-muted-foreground mb-12 text-lg">
            Have questions about our ingredients, bulk orders, or custom enchantments? Reach out below.
          </p>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 text-left max-w-2xl mx-auto bg-card/20 p-8 rounded-3xl border border-primary/10 backdrop-blur-sm">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">Name</label>
                <input
                  {...form.register("name")}
                  className="w-full bg-background border border-primary/20 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground"
                  placeholder="John Doe"
                />
                {form.formState.errors.name && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">Email</label>
                <input
                  {...form.register("email")}
                  className="w-full bg-background border border-primary/20 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground"
                  placeholder="john@example.com"
                />
                {form.formState.errors.email && (
                  <p className="text-destructive text-sm mt-1">{form.formState.errors.email.message}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground/80">Message</label>
              <textarea
                {...form.register("message")}
                className="w-full bg-background border border-primary/20 rounded-xl px-4 py-3 min-h-[150px] focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all text-foreground"
                placeholder="How can we assist you?"
              />
              {form.formState.errors.message && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.message.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-8 py-3 bg-primary/20 border border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground font-semibold rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mx-auto"
            >
              {isSubmitting ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> Sending...</>
              ) : (
                "Send Message"
              )}
            </button>

          </form>
        </motion.div>
      </div>
    </section>
  );
}
