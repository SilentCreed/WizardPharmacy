import { useMutation } from "@tanstack/react-query";
import { api, type ContactInput, type ContactResponse } from "@shared/routes";

export function useCreateContact() {
  return useMutation({
    mutationFn: async (data: ContactInput) => {
      const validated = api.contacts.create.input.parse(data);
      const res = await fetch(api.contacts.create.path, {
        method: api.contacts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      const resData = await res.json();
      
      if (!res.ok) {
        if (res.status === 400) {
          throw new Error(resData.message || "Validation failed");
        }
        throw new Error("Failed to submit contact form");
      }
      
      return api.contacts.create.responses[201].parse(resData) as ContactResponse;
    },
  });
}
