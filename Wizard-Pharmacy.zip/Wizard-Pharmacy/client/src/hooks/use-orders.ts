import { useMutation } from "@tanstack/react-query";
import { api, type OrderInput, type OrderResponse } from "@shared/routes";

export function useCreateOrder() {
  return useMutation({
    mutationFn: async (data: OrderInput) => {
      const validated = api.orders.create.input.parse(data);
      const res = await fetch(api.orders.create.path, {
        method: api.orders.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      const resData = await res.json();
      
      if (!res.ok) {
        if (res.status === 400) {
          throw new Error(resData.message || "Validation failed");
        }
        throw new Error("Failed to create order");
      }
      
      return api.orders.create.responses[201].parse(resData) as OrderResponse;
    },
  });
}
