import { Navbar } from "@/components/navbar";
import { HeroSection } from "@/components/hero-section";
import { AboutSection } from "@/components/about-section";
import { TeamSection } from "@/components/team-section";
import { OrderSection } from "@/components/order-section";
import { ContactSection } from "@/components/contact-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col pt-20">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <AboutSection />
        <TeamSection />
        <OrderSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
