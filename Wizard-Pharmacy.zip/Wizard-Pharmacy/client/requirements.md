## Packages
framer-motion | Page transitions and scroll-triggered magical animations
lucide-react | Already in base, but explicitly noting for magical icons
@hookform/resolvers | Form validation

## Notes
EmailJS integration requires the user to add credentials later in the `onSubmit` placeholder of the Order Form component.
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  sans: ["var(--font-sans)"],
}
