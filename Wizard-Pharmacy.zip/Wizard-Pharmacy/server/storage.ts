import { db } from "./db";
import { 
  products, orders, contacts,
  type Product, type Order, type Contact,
  type InsertProduct, type InsertOrder, type InsertContact
} from "@shared/schema";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  createContact(contact: InsertContact): Promise<Contact>;
  createProduct(product: InsertProduct): Promise<Product>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }
}

export const storage = new DatabaseStorage();
