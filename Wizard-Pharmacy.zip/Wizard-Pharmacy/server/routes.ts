import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const products = await storage.getProducts();
  if (products.length === 0) {
    await storage.createProduct({
      name: "Calming Lavender Potion",
      description: "A soothing blend of lavender essential oil with silver glitter and tiny star charms to calm the mind.",
      price: "$8.00",
      imageUrl: "https://images.unsplash.com/photo-1549416878-b9ca95e1bb3b?auto=format&fit=crop&q=80&w=600"
    });
    await storage.createProduct({
      name: "Energizing Citrus Potion",
      description: "Bright orange oils mixed with gold glitter and sun charms to start your day with energy.",
      price: "$8.00",
      imageUrl: "https://images.unsplash.com/photo-1608579042592-3a5f83c16262?auto=format&fit=crop&q=80&w=600"
    });
    await storage.createProduct({
      name: "Focus Peppermint Potion",
      description: "Cool peppermint oils with deep blue glitters and moon charms to help you stay focused.",
      price: "$8.00",
      imageUrl: "https://images.unsplash.com/photo-1585292408337-b649219e8c45?auto=format&fit=crop&q=80&w=600"
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await seedDatabase();

  app.get(api.products.list.path, async (req, res) => {
    const allProducts = await storage.getProducts();
    res.json(allProducts);
  });

  app.post(api.orders.create.path, async (req, res) => {
    try {
      const input = api.orders.create.input.parse(req.body);
      const order = await storage.createOrder(input);
      res.status(201).json(order);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.contacts.create.path, async (req, res) => {
    try {
      const input = api.contacts.create.input.parse(req.body);
      const contact = await storage.createContact(input);
      res.status(201).json(contact);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
